<?php
include '../system.inc.php';
include 'functions.inc.php';

verifyAction('DELETEFILE');
checkAccess('DELETEFILE');

$path = trim($_POST['f']);
verifyPath($path);

if(is_file(fixPath($path))){
  if(unlink(fixPath($path)))
    echo getSuccessRes();
  else
    echo getErrorRes(t('E_DeletеFile').' '.basename($path));
}
else
  echo getErrorRes(t('E_DeleteFileInvalidPath'));
?>
