<?php
include '../system.inc.php';
include 'functions.inc.php';

verifyAction('RENAMEFILE');
checkAccess('RENAMEFILE');

$path = trim(empty($_POST['f'])?'':$_POST['f']);
$name = trim(empty($_POST['n'])?'':$_POST['n']);
verifyPath($path);

if(is_file(fixPath($path))){
  if(!RoxyFile::CanUploadFile($name))
    echo getErrorRes(t('E_FileExtensionForbidden').' ".'.RoxyFile::GetExtension($name).'"');
  elseif(rename(fixPath($path), dirname(fixPath($path)).'/'.$name))
    echo getSuccessRes();
  else
    echo getErrorRes(t('E_RenameFile').' '.basename($path));
}
else
  echo getErrorRes(t('E_RenameFileInvalidPath'));
?>
