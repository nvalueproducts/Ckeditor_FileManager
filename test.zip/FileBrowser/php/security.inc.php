<?php
function checkAccess($action){
  if(!session_id())
    session_start();
}
?>
