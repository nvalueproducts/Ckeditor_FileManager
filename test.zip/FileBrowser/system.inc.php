<?php
error_reporting(0);
ini_set('display_errors', 'off');
define('BASE_PATH', dirname (__FILE__));
date_default_timezone_set('UTC');
mb_internal_encoding("UTF-8");
mb_regex_encoding(mb_internal_encoding());
?>
